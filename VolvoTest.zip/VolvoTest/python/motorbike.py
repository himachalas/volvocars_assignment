from vehicle import Vehicle


class Motorbike(Vehicle):
    def get_vehicle_type(self):
        return "Motorbike"

﻿using congestion_tax_calculator;
using NUnit.Framework;
using System;

namespace congestion_tax_calculator_tests
{
    public class VehicleTaxCalculatorTest : IVehicleTaxCalculator
    {
        public int CalculateTax(IVehicle vehicle, DateTime date)
        {   
            return 42; 
        }
    }

    [TestFixture]
    public class VehicleTaxCalculatorTestTests
    {
        [Test]
        public void CalculateTax_ReturnsExpectedResult()
        {
            var calculator = new VehicleTaxCalculatorTest();
            IVehicle vehicle = new MockVehicle("Car");
            DateTime date = DateTime.Now;
            int result = calculator.CalculateTax(vehicle, date);
            Assert.AreEqual(42, result); 
        }
    }

  
    public class MockVehicle : IVehicle
    {
        private readonly string _vehicleType;
        public MockVehicle(string vehicleType)
        {
            _vehicleType = vehicleType;
        }
        public string GetVehicleType()
        {
            return _vehicleType;
        }
    }
}

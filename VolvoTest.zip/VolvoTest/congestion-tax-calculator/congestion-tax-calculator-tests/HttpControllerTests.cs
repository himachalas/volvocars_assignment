﻿using NUnit.Framework;
using Microsoft.AspNetCore.Mvc;
using congestion_tax_calculator;
using Moq;
using System;

namespace congestion_tax_calculator_tests
{
    [TestFixture]
    public class HttpControllerTests
    {
        [Test]
        public void CalculateCongestionTax_ReturnsExpectedResult()
        {
         
            var calculatorMock = new Mock<IVehicleTaxCalculator>();
            calculatorMock.Setup(x => x.CalculateTax(It.IsAny<IVehicle>(), It.IsAny<DateTime>())).Returns(42);
            var httpController = new HttpController(calculatorMock.Object);
            IVehicle vehicle = new Mock<IVehicle>().Object;
            DateTime date = DateTime.Now;

     
            var result = httpController.CalculateCongestionTax(vehicle, date) as OkObjectResult;

   
            Assert.IsNotNull(result);
            Assert.AreEqual(200, result.StatusCode);
            Assert.AreEqual(42, result.Value); // Replace with your expected result
        }

        [Test]
        public void CalculateCongestionTax_WithNullVehicle_ReturnsBadRequest()
        {
        
            var calculatorMock = new Mock<IVehicleTaxCalculator>();
            var httpController = new HttpController(calculatorMock.Object);

       
            var result = httpController.CalculateCongestionTax(null, DateTime.Now) as BadRequestObjectResult;


            Assert.IsNotNull(result);
            Assert.AreEqual(400, result.StatusCode);
            Assert.AreEqual("Vehicle cannot be null", result.Value as string);
        }

        [Test]
        public void CalculateCongestionTax_WithInvalidDate_ReturnsBadRequest()
        {
      
            var calculatorMock = new Mock<IVehicleTaxCalculator>();
            var httpController = new HttpController(calculatorMock.Object);

         
            var result = httpController.CalculateCongestionTax(new Mock<IVehicle>().Object, default) as BadRequestObjectResult;

       
            Assert.IsNotNull(result);
            Assert.AreEqual(400, result.StatusCode);
            Assert.AreEqual("Invalid date", result.Value as string);
        }

        [Test]
        public void CalculateCongestionTax_WithZeroTax_ReturnsZeroTax()
        {
      
            var calculatorMock = new Mock<IVehicleTaxCalculator>();
            calculatorMock.Setup(x => x.CalculateTax(It.IsAny<IVehicle>(), It.IsAny<DateTime>())).Returns(0);
            var httpController = new HttpController(calculatorMock.Object);
            IVehicle vehicle = new Mock<IVehicle>().Object;
            DateTime date = DateTime.Now;

   
            var result = httpController.CalculateCongestionTax(vehicle, date) as OkObjectResult;

    
            Assert.IsNotNull(result);
            Assert.AreEqual(200, result.StatusCode);
            Assert.AreEqual(0, result.Value);
        }

        [Test]
        public void CalculateCongestionTax_WithException_ReturnsBadRequest()
        {
      
            var calculatorMock = new Mock<IVehicleTaxCalculator>();
            calculatorMock.Setup(x => x.CalculateTax(It.IsAny<IVehicle>(), It.IsAny<DateTime>())).Throws(new Exception("Test exception"));
            var httpController = new HttpController(calculatorMock.Object);

        
            var result = httpController.CalculateCongestionTax(new Mock<IVehicle>().Object, DateTime.Now) as BadRequestObjectResult;

     
            Assert.IsNotNull(result);
            Assert.AreEqual(400, result.StatusCode);

            StringAssert.Contains("Error calculating congestion tax", result.Value as string);
        }
    }
}

﻿using System;
// HttpControllerTests.cs
using NUnit.Framework;
using congestion_tax_calculator;

namespace congestion_tax_calculator_test
{


    [TestFixture]
    public class HttpControllerTests
    {
        [Test]
        public void CalculateCongestionTax_ReturnsExpectedResult()
        {
            // Arrange
            var calculator = new VehicleTaxCalculatorTest(); // or use dependency injection
            var httpController = new HttpController(calculator);

            // Act
            var result = httpController.CalculateCongestionTax(/* provide necessary parameters */);

            // Assert
            Assert.AreEqual(42, result); // Replace with your expected result
        }
    }

}

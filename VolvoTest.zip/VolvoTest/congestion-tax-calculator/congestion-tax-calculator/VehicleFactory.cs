﻿namespace congestion_tax_calculator
{
    public class VehicleFactory
    {
        public static IVehicle? CreateVehicle(VehicleTypes vehicleType)
        {
            return vehicleType switch
            {
                VehicleTypes.Car => new Car(),
                VehicleTypes.Motorbike => new Motorbike(),
                _ => null,
            };
        }
    }
}

﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Globalization;
using System.Linq;
using System.Threading.Tasks;

namespace congestion_tax_calculator
{
    public class HttpController
    {
        private readonly IVehicleTaxCalculator _calculator;

        public HttpController(IVehicleTaxCalculator calculator)
        {
            _calculator = calculator ?? throw new ArgumentNullException(nameof(calculator));
        }

        public IActionResult CalculateCongestionTax(IVehicle vehicle, DateTime date)
        {
            try
            {
               
                if (vehicle == null)
                {
                    return new BadRequestObjectResult("Vehicle cannot be null");
                }

                if (date == default)
                {
                    return new BadRequestObjectResult("Invalid date");
                }

                int congestionTax = _calculator.CalculateTax(vehicle, date);                             
                return new OkObjectResult(congestionTax);
            }
            catch (Exception ex)
            {               
                Console.WriteLine($"Error calculating congestion tax: {ex}");              
                return new BadRequestObjectResult("Error calculating congestion tax");
            }
        }
    }
}

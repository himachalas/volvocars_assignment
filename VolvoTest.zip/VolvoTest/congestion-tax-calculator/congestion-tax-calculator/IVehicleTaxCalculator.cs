﻿namespace congestion_tax_calculator
{
    public interface IVehicleTaxCalculator
    {
        int CalculateTax(IVehicle vehicle, DateTime date);
    }
}

﻿using System;
using System.Collections.Generic;

namespace congestion_tax_calculator
{
    public enum VehicleTypes
    {
        Car,
        Motorbike
    }
    public class CongestionTaxCalculator
    {
        private const int MaxTaxPerDay = 60;

        private static readonly Dictionary<string, int> TaxRates = new Dictionary<string, int>
        {
            {"06:00", 8},
            {"06:30", 13},
            {"07:00", 18},
            {"08:00", 13},
            {"08:30", 8},
            {"15:00", 13},
            {"15:30", 18},
            {"17:00", 13},
            {"18:00", 8},
            {"18:30", 0}
        };

        public int GetTax(IVehicle vehicle, DateTime[] dates)
        {
            DateTime intervalStart = dates[0];
            int totalFee = 0;

            foreach (DateTime date in dates)
            {
                int nextFee = GetTollFee(date, vehicle);
                int tempFee = GetTollFee(intervalStart, vehicle);

                long minutes = (long)(date - intervalStart).TotalMinutes;

                if (minutes <= 60)
                {
                    if (totalFee > 0) totalFee -= tempFee;
                    if (nextFee >= tempFee) tempFee = nextFee;
                    totalFee += tempFee;
                }
                else
                {
                    totalFee += nextFee;
                }
            }

            return Math.Min(totalFee, MaxTaxPerDay);
        }

        private bool IsTollFreeVehicle(IVehicle vehicle)
        {
            if (vehicle == null) return false;

            string vehicleType = vehicle.GetVehicleType();
            return Enum.TryParse(vehicleType, out TollFreeVehicles tollFreeVehicle) &&
                   tollFreeVehicle != TollFreeVehicles.None;
        }

        public int GetTollFee(DateTime date, IVehicle vehicle)
        {
            if (IsTollFreeDate(date) || IsTollFreeVehicle(vehicle)) return 0;

            int hour = date.Hour;
            int minute = date.Minute;

            switch (hour)
            {
                case 6 when minute >= 0 && minute <= 29:
                    return 8;
                case 6 when minute >= 30 && minute <= 59:
                    return 13;
                case 7 when minute >= 0 && minute <= 59:
                    return 18;
                case 8 when minute >= 0 && minute <= 29:
                    return 13;
                case 8 when hour >= 8 && hour <= 14 && minute >= 30 && minute <= 59:
                    return 8;
                case 15 when minute >= 0 && minute <= 29:
                    return 13;
                case 15 when minute >= 0 || hour == 16 && minute <= 59:
                    return 18;
                case 17 when minute >= 0 && minute <= 59:
                    return 13;
                case 18 when minute >= 0 && minute <= 29:
                    return 8;
                default:
                    return 0;
            }
        }

        private bool IsTollFreeDate(DateTime date)
        {
            int year = date.Year;
            int month = date.Month;
            int day = date.Day;

            if (date.DayOfWeek == DayOfWeek.Saturday || date.DayOfWeek == DayOfWeek.Sunday) return true;

            if (year == 2013)
            {
                switch (month)
                {
                    case 1 when day == 1:
                    case 3 when day == 28 || day == 29:
                    case 4 when day == 1 || day == 30:
                    case 5 when day == 1 || day == 8 || day == 9:
                    case 6 when day == 5 || day == 6 || day == 21:
                    case 7:
                    case 11 when day == 1:
                    case 12 when day == 24 || day == 25 || day == 26 || day == 31:
                        return true;
                }
            }

            return false;
        }

        private enum TollFreeVehicles
        {
            None = 0,
            Motorcycle,
            Tractor,
            Emergency,
            Diplomat,
            Foreign,
            Military
        }
    }
}

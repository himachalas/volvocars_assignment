﻿namespace congestion_tax_calculator
{
    public interface IVehicle
    {
        string GetVehicleType();
    }
}
